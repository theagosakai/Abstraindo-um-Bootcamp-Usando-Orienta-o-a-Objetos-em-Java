<h1 align="center">
  Java OOP - Abstraindo um Bootcamp Usando Orientação a Objetos em Java
</h1>

## 👩🏻‍💻 Projeto

<strong>Repositório com o desafio de projeto da plataforma DIO</strong> em que foi trabalhada a <strong>programação orientada a objetos em Java</strong> a partir da abstração de um bootcamp. Nesse projeto foram abordados:
- preparação de ambiente na IDE Eclipse, 
- abstração e encapsulamento,
- herança e polimorfismo,
- criação de métodos,
- criação de classes e suas interligações.

## 💫 Tecnologias

Esse projeto foi desenvolvido com as seguintes tecnologias:

- Java
- IDE Eclipse
